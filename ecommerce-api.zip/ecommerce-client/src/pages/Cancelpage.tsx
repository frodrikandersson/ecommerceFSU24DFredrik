export const Cancelpage = () => {
  
    return (
        <>
        </>
    );
  };