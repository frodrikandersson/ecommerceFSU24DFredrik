import classes from "./Layout.module.css";

export const Orderpage = () => {

    return (
      <div>

      </div>
    );
  };