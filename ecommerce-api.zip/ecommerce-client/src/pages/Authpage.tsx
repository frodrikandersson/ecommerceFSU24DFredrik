import classes from "./Layout.module.css";

export function Authpage() {
  return (
    <div>
        
    </div>
  );
}
