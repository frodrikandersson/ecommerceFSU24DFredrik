import { AdminPanel } from "../components/AdminPanel/index.tsx";


export function AdminPage() {
  return (
      <AdminPanel />
  );
}
