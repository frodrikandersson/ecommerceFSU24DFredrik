export * from './AdminPanel.tsx';
export { default } from './AdminPanel.tsx';