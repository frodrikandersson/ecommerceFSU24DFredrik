
const NotFound = () => {
    
    return (
        <h1>Oops, seems like the page you're looking for doesn't exist!</h1>
    )
}

export default NotFound;